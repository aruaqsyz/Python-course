import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    database="clothes",
    user="root",
    password="mysql" )

mycursor = conn.cursor()

# sql = "UPDATE Buyers SET bonuses = 88 WHERE id <= 3"

# mycursor.execute(sql)

# conn.commit()

# print(mycursor.rowcount, "record(s) affected")

mycursor.execute("SELECT * FROM Buyers")

myresult = mycursor.fetchall()

for x in myresult:
  print(x)